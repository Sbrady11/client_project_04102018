# client_project_04102018
Software Solutions client
